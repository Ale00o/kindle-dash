URL="https://raw.githubusercontent.com/Ale00o/kindle-dash/main/dash1.png"
CACERT="/mnt/us/extensions/dashboard/cacert.pem"
ERRORE="/mnt/us/extensions/dashboard/errore.png"
XH="/mnt/us/extensions/dashboard/bin/xh"
